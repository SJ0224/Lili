public interface Position {
     public Object element();
}
